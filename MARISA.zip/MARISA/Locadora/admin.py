from django.contrib import admin
from Locadora.models import Categoria, Filme, Cliente, Locacao  

# Register your models here.

@admin.register (Categoria)
class CategoriaAdmin (admin.ModelAdmin):
    list_display = ('nome',)

@admin.register (Filme)
class FilmeAdmin(admin.ModelAdmin):
    list_display = ('valor', 'titulo')

@admin.register (Cliente)
class ClienteAdmin (admin.ModelAdmin):
    list_display = ('email', 'nome')

@admin.register (Locacao)
class LocacaoAdmin(admin.ModelAdmin):
    list_display = ('data', 'nome')
    